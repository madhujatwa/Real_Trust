package com.fliper.controller;

import com.fliper.dto.ApiError;
import com.fliper.dto.SubscriberDto;
import com.fliper.exception.ResourceNotFoundException;
import com.fliper.service.SubscriberService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/subscribers")
@RequiredArgsConstructor
public class SubscriberController {

    private final SubscriberService subscriberService;

    @PostMapping
    public ResponseEntity<?> createSubscriber(@RequestBody SubscriberDto subscriberDto, HttpServletRequest request) {
        try {
            SubscriberDto created = subscriberService.createSubscriber(subscriberDto);
            return ResponseEntity.ok(created);
        } catch (RuntimeException ex) {
            ApiError error = ApiError.builder()
                    .timestamp(LocalDateTime.now())
                    .status(HttpStatus.BAD_REQUEST.value())
                    .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                    .message(ex.getMessage())
                    .path(request.getRequestURI())
                    .build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @GetMapping
    public ResponseEntity<List<SubscriberDto>> getAllSubscribers() {
        return ResponseEntity.ok(subscriberService.getAllSubscribers());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getSubscriberById(@PathVariable Long id, HttpServletRequest request) {
        try {
            SubscriberDto subscriber = subscriberService.getSubscriberById(id);
            return ResponseEntity.ok(subscriber);
        } catch (ResourceNotFoundException ex) {
            ApiError error = ApiError.builder()
                    .timestamp(LocalDateTime.now())
                    .status(HttpStatus.NOT_FOUND.value())
                    .error(HttpStatus.NOT_FOUND.getReasonPhrase())
                    .message(ex.getMessage())
                    .path(request.getRequestURI())
                    .build();
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSubscriber(@PathVariable Long id, HttpServletRequest request) {
        try {
            subscriberService.deleteSubscriber(id);
            return ResponseEntity.noContent().build();
        } catch (ResourceNotFoundException ex) {
            ApiError error = ApiError.builder()
                    .timestamp(LocalDateTime.now())
                    .status(HttpStatus.NOT_FOUND.value())
                    .error(HttpStatus.NOT_FOUND.getReasonPhrase())
                    .message(ex.getMessage())
                    .path(request.getRequestURI())
                    .build();
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
        }
    }
}
