package com.fliper.service;

import com.fliper.dto.ClientDto;

import java.util.List;

public interface ClientService {

    ClientDto createClient(ClientDto clientDto);

    List<ClientDto> getAllClients();

    ClientDto getClientById(Long id);

    ClientDto updateClient(Long id, ClientDto clientDto);

    void deleteClient(Long id);
}
