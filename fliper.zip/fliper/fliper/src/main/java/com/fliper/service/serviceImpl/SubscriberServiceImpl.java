package com.fliper.service.serviceImpl;

import com.fliper.dto.SubscriberDto;
import com.fliper.entity.Subscriber;
import com.fliper.exception.ResourceNotFoundException;
import com.fliper.repository.SubscriberRepository;
import com.fliper.service.SubscriberService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SubscriberServiceImpl implements SubscriberService {

    private final SubscriberRepository subscriberRepository;
    private final ModelMapper modelMapper;

    /**
     * Create a new subscriber and save to DB
     */
    @Override
    @Transactional
    public SubscriberDto createSubscriber(SubscriberDto subscriberDto) {

        // Check if email already exists
        if (subscriberRepository.existsByEmail(subscriberDto.getEmail())) {
            throw new RuntimeException("Email already subscribed!");
        }

        // Map DTO to Entity
        Subscriber subscriber = modelMapper.map(subscriberDto, Subscriber.class);

        // Save to database
        Subscriber saved = subscriberRepository.save(subscriber);

        // Map Entity to DTO
        return modelMapper.map(saved, SubscriberDto.class);
    }

    /**
     * Get all subscribers
     */
    @Override
    public List<SubscriberDto> getAllSubscribers() {
        return subscriberRepository.findAll()
                .stream()
                .map(sub -> modelMapper.map(sub, SubscriberDto.class))
                .collect(Collectors.toList());
    }

    /**
     * Get a subscriber by ID
     */
    @Override
    public SubscriberDto getSubscriberById(Long id) {
        Subscriber subscriber = subscriberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subscriber not found with id: " + id));
        return modelMapper.map(subscriber, SubscriberDto.class);
    }

    /**
     * Delete a subscriber by ID
     */
    @Override
    @Transactional
    public void deleteSubscriber(Long id) {
        Subscriber subscriber = subscriberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subscriber not found with id: " + id));
        subscriberRepository.delete(subscriber);
    }
}
