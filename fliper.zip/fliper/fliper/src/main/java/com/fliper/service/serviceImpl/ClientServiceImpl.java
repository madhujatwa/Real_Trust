package com.fliper.service.serviceImpl;

import com.fliper.dto.ClientDto;
import com.fliper.entity.Client;
import com.fliper.repository.ClientRepository;
import com.fliper.service.ClientService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ClientServiceImpl implements ClientService {

    private final ClientRepository clientRepository;
    private final ModelMapper modelMapper;

    @Override
    public ClientDto createClient(ClientDto clientDto) {

        if (clientRepository.existsByName(clientDto.getName())) {
            throw new RuntimeException("Client with this name already exists");
        }

        Client client = modelMapper.map(clientDto, Client.class);

        Client savedClient = clientRepository.save(client);

        return modelMapper.map(savedClient, ClientDto.class);
    }

    @Override
    public List<ClientDto> getAllClients() {
        return clientRepository.findAll()
                .stream()
                .map(client -> modelMapper.map(client,ClientDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ClientDto getClientById(Long id) {

        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));

        return modelMapper.map(client, ClientDto.class);
    }


    @Override
    public ClientDto updateClient(Long id, ClientDto clientDto) {

        Client existing = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));

        // DTO → Entity mapping
        modelMapper.map(clientDto, existing);

        Client updated = clientRepository.save(existing);

        // Entity → DTO mapping
        return modelMapper.map(updated, ClientDto.class);
    }


    @Override
    public void deleteClient(Long id) {
        clientRepository.deleteById(id);
    }
}
