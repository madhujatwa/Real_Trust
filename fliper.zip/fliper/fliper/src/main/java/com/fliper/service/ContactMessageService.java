package com.fliper.service;

import com.fliper.dto.ContactMessageDto;
import java.util.List;

public interface ContactMessageService {

    ContactMessageDto saveMessage(ContactMessageDto contactMessageDto);

    List<ContactMessageDto> getAllMessages();

    ContactMessageDto getMessageById(Long id);

    void deleteMessage(Long id);
}
