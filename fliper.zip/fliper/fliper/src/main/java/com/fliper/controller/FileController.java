package com.fliper.controller;

import com.fliper.dto.FileResponse;
import com.fliper.service.FileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/files")
@RequiredArgsConstructor
public class FileController {

    private final FileService fileService;

    /**
     * Upload file and return FileResponse (with URL).
     */
    @PostMapping("/upload")
    public ResponseEntity<FileResponse> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            String savedFileName = fileService.storeFile(file);
            FileResponse response = FileResponse.builder()
                    .fileName(savedFileName)
                    .fileUrl("/uploads/" + savedFileName)
                    .message("File uploaded successfully!")
                    .success(true)
                    .build();
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception ex) {
            FileResponse error = FileResponse.builder()
                    .fileName(null)
                    .fileUrl(null)
                    .message("File upload failed: " + ex.getMessage())
                    .success(false)
                    .build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    /**
     * Upload file and return saved relative path (useful to store in DB as imageUrl),
     * but still wrapped in FileResponse for consistency.
     */
    @PostMapping("/upload/url")
    public ResponseEntity<FileResponse> uploadFileAndGetPath(@RequestParam("file") MultipartFile file) {
        try {
            String path = fileService.storeFileAndGetPath(file); // e.g. "uploads/abc.jpg" or "/uploads/abc.jpg"
            // extract fileName for response
            String fileName = path;
            int idx = path.lastIndexOf('/');
            if (idx >= 0 && idx + 1 < path.length()) {
                fileName = path.substring(idx + 1);
            }
            FileResponse response = FileResponse.builder()
                    .fileName(fileName)
                    .fileUrl(path.startsWith("/") ? path : "/" + path)
                    .message("File uploaded successfully!")
                    .success(true)
                    .build();
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception ex) {
            FileResponse error = FileResponse.builder()
                    .fileName(null)
                    .fileUrl(null)
                    .message("File upload failed: " + ex.getMessage())
                    .success(false)
                    .build();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    @DeleteMapping("/{fileName:.+}")
    public ResponseEntity<Void> deleteFile(@PathVariable String fileName) {
        fileService.deleteFile(fileName);
        return ResponseEntity.noContent().build();
    }
}
