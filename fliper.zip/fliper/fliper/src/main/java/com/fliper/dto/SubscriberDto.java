package com.fliper.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class SubscriberDto {
    private Long id;

    private String email;
}
