package com.fliper.service;

import com.fliper.dto.SubscriberDto;
import java.util.List;

public interface SubscriberService {

    SubscriberDto createSubscriber(SubscriberDto subscriberDto);

    List<SubscriberDto> getAllSubscribers();

    SubscriberDto getSubscriberById(Long id);

    void deleteSubscriber(Long id);
}
