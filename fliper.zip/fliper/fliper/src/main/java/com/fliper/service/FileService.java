package com.fliper.service;


import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public interface FileService {



    String storeFile(MultipartFile file);
    String storeFileAndGetPath(MultipartFile file); // optional: just returns saved relative path
    void deleteFile(String fileName);
}
