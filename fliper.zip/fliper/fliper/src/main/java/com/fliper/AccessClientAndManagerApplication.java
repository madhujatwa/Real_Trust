package com.fliper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccessClientAndManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccessClientAndManagerApplication.class, args);
	}

}
