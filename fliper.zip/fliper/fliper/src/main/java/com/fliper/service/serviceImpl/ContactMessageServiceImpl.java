package com.fliper.service.serviceImpl;

import com.fliper.dto.ContactMessageDto;
import com.fliper.entity.ContactMessage;
import com.fliper.repository.ContactMessageRepository;
import com.fliper.service.ContactMessageService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ContactMessageServiceImpl implements ContactMessageService {

    private final ContactMessageRepository contactMessageRepository;
    private final ModelMapper modelMapper;

    @Override
    public ContactMessageDto saveMessage(ContactMessageDto contactMessageDto) {

        // DTO → Entity
        ContactMessage entity = modelMapper.map(contactMessageDto, ContactMessage.class);

        // Save to DB
        ContactMessage saved = contactMessageRepository.save(entity);

        // Entity → DTO
        return modelMapper.map(saved, ContactMessageDto.class);
    }

    @Override
    public List<ContactMessageDto> getAllMessages() {

        return contactMessageRepository.findAll()
                .stream()
                .map(msg -> modelMapper.map(msg, ContactMessageDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public ContactMessageDto getMessageById(Long id) {

        ContactMessage message = contactMessageRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Message not found"));

        return modelMapper.map(message, ContactMessageDto.class);
    }

    @Override
    public void deleteMessage(Long id) {
        contactMessageRepository.deleteById(id);
    }
}
