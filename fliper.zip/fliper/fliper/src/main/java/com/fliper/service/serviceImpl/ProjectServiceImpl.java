package com.fliper.service.serviceImpl;

import com.fliper.dto.ProjectDto;
import com.fliper.entity.Project;
import com.fliper.repository.ProjectRepo;
import com.fliper.service.ProjectService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjectServiceImpl implements ProjectService {

    private final ModelMapper modelMapper;
    private final ProjectRepo projectRepo;


    @Override
    public ProjectDto createProject(ProjectDto projectDto) {

        if (projectRepo.existsByName(projectDto.getName())) {
            throw new RuntimeException("Project with this name already exists");
        }

        Project project = modelMapper.map(projectDto, Project.class);

        Project savedProject = projectRepo.save(project);

        return modelMapper.map(savedProject, ProjectDto.class);
    }



    @Override
    public ProjectDto updateProject(Long projectId, ProjectDto projectDto) {


        Project existingProject = projectRepo.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found with id: " + projectId));

        if (!existingProject.getName().equals(projectDto.getName())
                && projectRepo.existsByName(projectDto.getName())) {
            throw new RuntimeException("Another project with this name already exists");
        }

        // 3. Update fields
        existingProject.setName(projectDto.getName());
        existingProject.setImageUrl(projectDto.getImageUrl());
        existingProject.setDescription(projectDto.getDescription());

        // 4. Save updated project
        Project updatedProject = projectRepo.save(existingProject);

        // 5. Return DTO
        return modelMapper.map(updatedProject, ProjectDto.class);

    }

    @Override
    public List<ProjectDto> getAllProjects() {
        return projectRepo.findAll()
                .stream()
                .map(project -> modelMapper.map(project, ProjectDto.class))
                .toList();
    }

    @Override
    public ProjectDto getProjectById(String id) {

        Project project = projectRepo.findById(Long.valueOf(id))
                .orElseThrow(() -> new RuntimeException("Project not found with id: " + id));

        return modelMapper.map(project, ProjectDto.class);
    }


    @Override
    public void deleteProject(String id) {

        Long projectId;

        try {
            projectId = Long.parseLong(id);
        } catch (NumberFormatException e) {
            throw new RuntimeException("Invalid project ID format");
        }

        // Check if project exists
        Project project = projectRepo.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found with id: " + id));

        // Delete project
        projectRepo.delete(project);
    }

}
