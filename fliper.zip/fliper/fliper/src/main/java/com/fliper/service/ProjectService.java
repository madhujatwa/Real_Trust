package com.fliper.service;

import com.fliper.dto.ProjectDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ProjectService {

    ProjectDto createProject(ProjectDto projectDto);
    ProjectDto updateProject(Long projectId,ProjectDto projectDto);
    List<ProjectDto> getAllProjects();

    ProjectDto getProjectById(String id);

    void deleteProject(String id);

}
