package com.fliper.service.serviceImpl;

import com.fliper.exception.FileStorageException;
import com.fliper.service.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.util.UUID;

@Service
@Slf4j
public class FileServiceImpl implements FileService {

    private final Path uploadPath; // normalized absolute path

    // Constructor injection with correct @Value
    public FileServiceImpl(@Value("${app.file.upload-dir}") String uploadDir) {
        if (uploadDir == null || uploadDir.isBlank()) {
            uploadDir = "uploads";
        }

        this.uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();

        try {
            if (Files.notExists(this.uploadPath)) {
                Files.createDirectories(this.uploadPath);
            }
        } catch (IOException e) {
            throw new FileStorageException("Could not create upload directory: " + this.uploadPath, e);
        }
    }

    @Override
    public String storeFile(MultipartFile file) {
        try {
            if (file == null || file.isEmpty()) {
                throw new FileStorageException("File is empty");
            }

            String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
            if (originalFilename.contains("..")) {
                throw new FileStorageException("Filename contains invalid path sequence: " + originalFilename);
            }

            // build unique filename
            String ext = "";
            int dot = originalFilename.lastIndexOf('.');
            if (dot > 0) ext = originalFilename.substring(dot);

            String uniqueName = Instant.now().toEpochMilli() + "-" + UUID.randomUUID() + ext;

            Path target = this.uploadPath.resolve(uniqueName);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);

            return uniqueName;

        } catch (IOException ex) {
            throw new FileStorageException("Could not store file. Error: " + ex.getMessage(), ex);
        }
    }

    @Override
    public String storeFileAndGetPath(MultipartFile file) {
        String fileName = storeFile(file);
        // relative path for DB or frontend
        return "/" + uploadPath.getFileName().toString() + "/" + fileName;
    }

    @Override
    public void deleteFile(String fileName) {
        try {
            if (fileName == null || fileName.isBlank()) return;
            Path filePath = this.uploadPath.resolve(fileName).normalize();
            Files.deleteIfExists(filePath);
        } catch (IOException ex) {
            throw new FileStorageException("Could not delete file " + fileName, ex);
        }
    }
}
