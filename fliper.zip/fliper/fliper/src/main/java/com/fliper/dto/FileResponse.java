package com.fliper.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileResponse {
    private String fileName;     // actual stored file name
    private String fileUrl;      // full path or relative URL
    private String message;      // success message
    private boolean success;     // true/false
}
