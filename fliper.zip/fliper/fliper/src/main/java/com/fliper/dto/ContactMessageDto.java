package com.fliper.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ContactMessageDto {
    private Long id;

    private String fullName;
    private String email;
    private String mobileNumber;
    private String city;
}
